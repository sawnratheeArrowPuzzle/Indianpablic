import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut } from 'firebase/auth';
import { AlertCircle, X } from 'lucide-react';
import { auth, googleProvider } from './lib/firebase';
import { api } from './services/api';
import type { Package, PublicCatalogResponse, UserProfile } from './types/savvvn';
import { TopNav, type PublicRoute } from './components/common/TopNav';
import { Footer } from './components/common/Footer';
import { HomePage } from './components/public/HomePage';
import { PackagesPage, PackageDetailPage } from './components/public/PackagesView';
import { CheckoutView } from './components/public/CheckoutView';
import {
  AboutPage,
  ContactPage,
  FaqPage,
  PrivacyPage,
  SupportPage,
  TermsPage,
} from './components/public/StaticPages';
import { MemberPortal } from './components/dashboard/MemberPortal';
import { AdminPanel } from './components/admin/AdminPanel';

const SESSION_PKG_KEY = 'savvvn_pending_pkg';
const SESSION_REF_KEY = 'savvvn_ref_code';

export function App() {
  const [catalog, setCatalog] = useState<PublicCatalogResponse | null>(null);
  const [catalogError, setCatalogError] = useState<string | null>(null);
  const [route, setRoute] = useState<PublicRoute>('home');
  const [selectedPackageId, setSelectedPackageId] = useState<string>(() => {
    try {
      return sessionStorage.getItem(SESSION_PKG_KEY) || '';
    } catch {
      return '';
    }
  });
  const [referralCode, setReferralCode] = useState<string>(() => {
    try {
      return sessionStorage.getItem(SESSION_REF_KEY) || '';
    } catch {
      return '';
    }
  });

  const [user, setUser] = useState<UserProfile | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [authBusy, setAuthBusy] = useState(false);
  const [authNotice, setAuthNotice] = useState<string | null>(null);

  const loadCatalog = useCallback(async () => {
    setCatalogError(null);
    try {
      const data = await api.getPublicCatalog();
      setCatalog(data);
    } catch (err: any) {
      setCatalogError(err?.message || 'Unable to load SavvvnLab catalog.');
    }
  }, []);

  // Parse query params (?ref=CODE&pkg=PKG_ID&view=checkout) once on load
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const refParam = params.get('ref')?.trim();
      const pkgParam = params.get('pkg')?.trim();
      const viewParam = params.get('view')?.trim() as PublicRoute | null;

      if (refParam) {
        sessionStorage.setItem(SESSION_REF_KEY, refParam.toUpperCase());
        setReferralCode(refParam.toUpperCase());
      }
      if (pkgParam) {
        sessionStorage.setItem(SESSION_PKG_KEY, pkgParam);
        setSelectedPackageId(pkgParam);
        setRoute(viewParam === 'checkout' ? 'checkout' : 'package-detail');
      } else if (
        viewParam &&
        ['home', 'packages', 'about', 'contact', 'support', 'faq', 'terms', 'privacy'].includes(
          viewParam
        )
      ) {
        setRoute(viewParam);
      }
    } catch {
      // Ignore storage/URL parsing errors
    }
    loadCatalog();
  }, [loadCatalog]);

  // Listen to Firebase Auth state changes and synchronize server session
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (!fbUser) {
        setUser(null);
        setAuthReady(true);
        return;
      }

      try {
        let savedRef = '';
        try {
          savedRef = sessionStorage.getItem(SESSION_REF_KEY) || '';
        } catch {
          savedRef = '';
        }
        const { user: profile } = await api.establishSession(savedRef || referralCode);
        setUser(profile);
      } catch (err: any) {
        console.error('Session sync failed:', err);
        setAuthNotice(err?.message || 'Could not verify your account session.');
      } finally {
        setAuthReady(true);
      }
    });

    return () => unsubscribe();
  }, [referralCode]);

  const navigate = useCallback((nextRoute: PublicRoute) => {
    setRoute(nextRoute);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const selectedPackage = useMemo<Package | null>(() => {
    if (!catalog?.packages?.length) return null;
    if (selectedPackageId) {
      const match = catalog.packages.find((p) => p.id === selectedPackageId);
      if (match) return match;
    }
    return catalog.packages[0] || null;
  }, [catalog, selectedPackageId]);

  const handleGoogleSignIn = useCallback(
    async (destinationOnSuccess?: PublicRoute) => {
      if (authBusy) return;
      setAuthBusy(true);
      setAuthNotice(null);

      try {
        await signInWithPopup(auth, googleProvider);
        let savedRef = '';
        let pendingPkg = '';
        try {
          savedRef = sessionStorage.getItem(SESSION_REF_KEY) || '';
          pendingPkg = sessionStorage.getItem(SESSION_PKG_KEY) || '';
        } catch {
          savedRef = '';
          pendingPkg = '';
        }

        const { user: profile } = await api.establishSession(savedRef || referralCode);
        setUser(profile);

        if (destinationOnSuccess === 'checkout' || pendingPkg) {
          if (pendingPkg) {
            setSelectedPackageId(pendingPkg);
          }
          navigate('checkout');
        } else if (destinationOnSuccess) {
          navigate(destinationOnSuccess);
        } else {
          navigate(profile.role === 'admin' ? 'admin' : 'dashboard');
        }
      } catch (err: any) {
        const code = err?.code || '';
        if (code === 'auth/popup-closed-by-user' || code === 'auth/cancelled-popup-request') {
          setAuthNotice('Google login cancelled.');
        } else if (code === 'auth/popup-blocked') {
          setAuthNotice('Sign-in popup was blocked by your browser. Please allow popups and try again.');
        } else if (code === 'auth/unauthorized-domain') {
          setAuthNotice('This domain is not authorized for Google Sign-In in Firebase Auth.');
        } else {
          setAuthNotice(err?.message || 'Google sign-in could not be completed.');
        }
      } finally {
        setAuthBusy(false);
      }
    },
    [authBusy, navigate, referralCode]
  );

  const handleSelectPackage = useCallback(
    (pkg: Package) => {
      setSelectedPackageId(pkg.id);
      try {
        sessionStorage.setItem(SESSION_PKG_KEY, pkg.id);
      } catch {
        // Ignore storage error
      }
      navigate('package-detail');
    },
    [navigate]
  );

  const handleBuyPackage = useCallback(
    async (pkg: Package) => {
      setSelectedPackageId(pkg.id);
      try {
        sessionStorage.setItem(SESSION_PKG_KEY, pkg.id);
      } catch {
        // Ignore storage error
      }

      if (auth.currentUser && user) {
        navigate('checkout');
      } else {
        await handleGoogleSignIn('checkout');
      }
    },
    [handleGoogleSignIn, navigate, user]
  );

  const handleTopNavAuthAction = useCallback(() => {
    if (user) {
      navigate(user.role === 'admin' ? 'admin' : 'dashboard');
    } else {
      handleGoogleSignIn('dashboard');
    }
  }, [handleGoogleSignIn, navigate, user]);

  const handleLogout = useCallback(async () => {
    await signOut(auth);
    setUser(null);
    try {
      sessionStorage.removeItem(SESSION_PKG_KEY);
    } catch {
      // Ignore storage error
    }
    navigate('home');
  }, [navigate]);

  if (!catalog) {
    return (
      <div className="min-h-screen bg-[#F8FAFC] flex items-center justify-center p-6">
        {catalogError ? (
          <div className="max-w-md w-full bg-white border border-slate-200 rounded-xl p-6 space-y-4 text-center">
            <h1 className="font-display text-lg font-bold text-[#0B1E36]">
              SavvvnLab Catalog Unavailable
            </h1>
            <p className="text-sm text-slate-600">{catalogError}</p>
            <button
              type="button"
              onClick={loadCatalog}
              className="px-5 py-2.5 rounded-lg bg-[#0B1E36] text-white text-sm font-semibold hover:bg-[#132f53] cursor-pointer"
            >
              Retry
            </button>
          </div>
        ) : (
          <div className="text-center space-y-3">
            <div className="w-8 h-8 rounded-full border-2 border-[#0B1E36] border-t-transparent animate-spin mx-auto" />
            <p className="text-sm text-slate-600 font-medium">Loading SavvvnLab...</p>
          </div>
        )}
      </div>
    );
  }

  // Full-screen Admin Console (strictly gated by server-verified role)
  if (route === 'admin' && user?.role === 'admin') {
    return (
      <AdminPanel
        user={user}
        onOpenMemberDashboard={() => navigate('dashboard')}
        onGoPublicHome={() => {
          loadCatalog();
          navigate('home');
        }}
        onLogout={handleLogout}
      />
    );
  }

  // Full-screen Member Workspace
  if (route === 'dashboard' && user) {
    return (
      <MemberPortal
        user={user}
        catalog={catalog}
        onRefreshUser={(updated) => setUser(updated)}
        onBuyPackage={handleBuyPackage}
        onOpenAdmin={() => {
          if (user.role === 'admin') navigate('admin');
        }}
        onGoPublicHome={() => navigate('home')}
        onLogout={handleLogout}
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#F8FAFC] text-[#0F172A]">
      <TopNav
        currentRoute={route}
        onNavigate={navigate}
        user={user}
        onAuthAction={handleTopNavAuthAction}
      />

      {authNotice && (
        <div className="bg-amber-50 border-b border-amber-200 px-4 py-2.5">
          <div className="max-w-7xl mx-auto flex items-center justify-between gap-3 text-xs sm:text-sm text-amber-900">
            <div className="flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0 text-amber-700" />
              <span>{authNotice}</span>
            </div>
            <button
              type="button"
              onClick={() => setAuthNotice(null)}
              aria-label="Dismiss notice"
              className="p-1 rounded hover:bg-amber-100 cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {!authReady && (
        <div className="bg-slate-100 border-b border-slate-200 px-4 py-1.5 text-center text-xs text-slate-600">
          Checking session...
        </div>
      )}

      <main className="flex-1">
        {route === 'home' && (
          <HomePage
            catalog={catalog}
            onSelectPackage={handleSelectPackage}
            onBuyPackage={handleBuyPackage}
            onNavigate={navigate}
          />
        )}

        {route === 'packages' && (
          <PackagesPage
            catalog={catalog}
            onSelectPackage={handleSelectPackage}
            onBuyPackage={handleBuyPackage}
          />
        )}

        {route === 'package-detail' && selectedPackage && (
          <PackageDetailPage
            pkg={selectedPackage}
            catalog={catalog}
            onBack={() => navigate('packages')}
            onBuyPackage={handleBuyPackage}
          />
        )}

        {route === 'checkout' && selectedPackage && (
          <CheckoutView
            pkg={selectedPackage}
            catalog={catalog}
            user={user}
            referralCode={referralCode}
            onGoogleSignIn={() => handleGoogleSignIn('checkout')}
            onBack={() => navigate('package-detail')}
            onGoToDashboard={() => navigate('dashboard')}
          />
        )}

        {route === 'about' && <AboutPage catalog={catalog} onNavigate={navigate} />}
        {route === 'contact' && <ContactPage catalog={catalog} />}
        {route === 'support' && (
          <SupportPage
            user={user}
            onGoogleSignIn={() => handleGoogleSignIn('support')}
            onNavigate={navigate}
          />
        )}
        {route === 'faq' && <FaqPage />}
        {route === 'terms' && <TermsPage />}
        {route === 'privacy' && <PrivacyPage />}

        {/* If user navigated to dashboard/admin while signed out, show prompt cleanly */}
        {(route === 'dashboard' || route === 'admin') && !user && (
          <div className="max-w-lg mx-auto px-4 py-16 text-center space-y-4">
            <h1 className="font-display text-2xl font-bold text-[#0B1E36]">
              Sign in to access your SavvvnLab account
            </h1>
            <p className="text-sm text-slate-600">
              Use Google Sign-In to open your courses, referral links, wallet ledger, or administration console.
            </p>
            <div className="flex items-center justify-center gap-3">
              <button
                type="button"
                disabled={authBusy}
                onClick={() => handleGoogleSignIn(route)}
                className="px-6 py-2.5 rounded-lg bg-[#0B1E36] hover:bg-[#132f53] text-white text-sm font-semibold cursor-pointer disabled:opacity-60"
              >
                {authBusy ? 'Signing in...' : 'Continue with Google'}
              </button>
              <button
                type="button"
                onClick={() => navigate('home')}
                className="px-5 py-2.5 rounded-lg border border-slate-300 text-sm font-medium text-[#0B1E36] cursor-pointer"
              >
                Back Home
              </button>
            </div>
          </div>
        )}
      </main>

      <Footer
        onNavigate={navigate}
        onSelectPackage={handleSelectPackage}
        packages={catalog.packages}
        settings={catalog.settings}
      />
    </div>
  );
}

export default App;
