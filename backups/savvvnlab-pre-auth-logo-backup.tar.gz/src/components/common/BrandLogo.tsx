import React, { useState } from 'react';

export const SAVVVN_LOGO_URL = '/assets/aistudio/IMG-20261121-WA2400_eba22879.jpg';

interface BrandLogoProps {
  variant?: 'wordmark' | 'full' | 'play';
  className?: string;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({ variant = 'play', className = '' }) => {
  const [imgFailed, setImgFailed] = useState(false);

  if (variant === 'full') {
    return (
      <div className={`inline-flex items-center justify-center ${className}`}>
        {!imgFailed ? (
          <img
            src={SAVVVN_LOGO_URL}
            alt="SavvvnLab — Learn · Create · Grow"
            referrerPolicy="no-referrer"
            onError={() => setImgFailed(true)}
            className="h-24 w-auto object-contain rounded-lg"
          />
        ) : (
          <span className="font-display text-2xl font-bold tracking-tight text-[#0B1530]">
            SavvvnLab
          </span>
        )}
      </div>
    );
  }

  return (
    <span className={`inline-flex items-center gap-2.5 whitespace-nowrap shrink-0 ${className}`}>
      <svg
        width="30"
        height="30"
        viewBox="0 0 36 36"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
        className="shrink-0"
      >
        <defs>
          <linearGradient id="savvvnPlayGrad" x1="0" y1="0" x2="36" y2="36" gradientUnits="userSpaceOnUse">
            <stop offset="0%" stopColor="#8B5CF6" />
            <stop offset="100%" stopColor="#4F1CEB" />
          </linearGradient>
        </defs>
        <path
          d="M7 7.2C7 4.4 10.1 2.7 12.5 4.2L30.2 15C32.5 16.4 32.5 19.6 30.2 21L12.5 31.8C10.1 33.3 7 31.6 7 28.8V7.2Z"
          fill="url(#savvvnPlayGrad)"
        />
        <path
          d="M14.5 12.5L23.5 18L14.5 23.5V12.5Z"
          fill="#FFFFFF"
        />
      </svg>
      <span className="font-display text-xl font-bold tracking-tight whitespace-nowrap shrink-0">
        SavvvnLab
      </span>
    </span>
  );
};
