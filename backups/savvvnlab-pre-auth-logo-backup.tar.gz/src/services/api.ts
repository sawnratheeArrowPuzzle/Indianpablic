import { auth } from '../lib/firebase';
import type {
  AdminOverviewResponse,
  AdminSettings,
  Course,
  MemberOverviewResponse,
  Order,
  Package,
  Payment,
  PublicCatalogResponse,
  UserProfile,
  Withdrawal,
} from '../types/savvvn';

async function getAuthHeaders(): Promise<HeadersInit> {
  const user = auth.currentUser;
  if (!user) {
    throw new Error('Please sign in with Google to continue.');
  }
  const idToken = await user.getIdToken();
  return {
    'Content-Type': 'application/json',
    Authorization: `Bearer ${idToken}`,
  };
}

async function requestJson<T>(url: string, options: RequestInit = {}, authenticated = false): Promise<T> {
  const headers: HeadersInit = authenticated
    ? await getAuthHeaders()
    : { 'Content-Type': 'application/json' };

  const res = await fetch(url, {
    ...options,
    headers: {
      ...headers,
      ...(options.headers || {}),
    },
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data?.error || data?.message || `Request failed (${res.status})`);
  }
  return data as T;
}

export const api = {
  // Public
  getPublicCatalog: () => requestJson<PublicCatalogResponse>('/api/public/catalog'),

  submitPublicContact: (payload: { name: string; email: string; subject: string; message: string }) =>
    requestJson<{ success: boolean }>('/api/public/contact', {
      method: 'POST',
      body: JSON.stringify(payload),
    }),

  // Session & Member
  establishSession: (referralCode?: string | null) =>
    requestJson<{ user: UserProfile }>(
      '/api/auth/session',
      { method: 'POST', body: JSON.stringify({ referralCode: referralCode || '' }) },
      true
    ),

  getMemberOverview: () => requestJson<MemberOverviewResponse>('/api/me/overview', {}, true),

  updateProfile: (payload: { displayName: string; phone: string; upiId: string }) =>
    requestJson<{ user: UserProfile }>(
      '/api/me/profile',
      { method: 'PATCH', body: JSON.stringify(payload) },
      true
    ),

  createOrder: (packageId: string, referralCode?: string | null) =>
    requestJson<{ order: Order }>(
      '/api/orders',
      { method: 'POST', body: JSON.stringify({ packageId, referralCode: referralCode || '' }) },
      true
    ),

  submitUpiPayment: (payload: { orderId: string; utr: string; screenshotUrl: string }) =>
    requestJson<{ payment: Payment; order: Order }>(
      '/api/payments/submit',
      { method: 'POST', body: JSON.stringify(payload) },
      true
    ),

  requestWithdrawal: (payload: { amount: number; upiId: string }) =>
    requestJson<{ withdrawal: Withdrawal }>(
      '/api/withdrawals/request',
      { method: 'POST', body: JSON.stringify(payload) },
      true
    ),

  markNotificationRead: (notificationId?: string) =>
    requestJson<{ success: boolean }>(
      '/api/notifications/read',
      { method: 'POST', body: JSON.stringify({ notificationId }) },
      true
    ),

  createSupportTicket: (payload: { subject: string; message: string }) =>
    requestJson<{ success: boolean }>(
      '/api/support/tickets',
      { method: 'POST', body: JSON.stringify(payload) },
      true
    ),

  // Admin
  getAdminOverview: () => requestJson<AdminOverviewResponse>('/api/admin/overview', {}, true),

  verifyPayment: (paymentId: string, action: 'approve' | 'reject', adminNote?: string) =>
    requestJson<{ payment: Payment; order: Order }>(
      `/api/admin/payments/${paymentId}/verify`,
      { method: 'POST', body: JSON.stringify({ action, adminNote }) },
      true
    ),

  refundOrder: (orderId: string, reason: string) =>
    requestJson<{ order: Order }>(
      `/api/admin/orders/${orderId}/refund`,
      { method: 'POST', body: JSON.stringify({ reason }) },
      true
    ),

  commissionAction: (id: string, action: 'approve' | 'reverse', note?: string) =>
    requestJson<{ success: boolean }>(
      `/api/admin/commissions/${id}/action`,
      { method: 'POST', body: JSON.stringify({ action, note }) },
      true
    ),

  withdrawalAction: (
    id: string,
    action: 'approve' | 'paid' | 'reject',
    payload?: { payoutReference?: string; adminNote?: string }
  ) =>
    requestJson<{ withdrawal: Withdrawal }>(
      `/api/admin/withdrawals/${id}/action`,
      { method: 'POST', body: JSON.stringify({ action, ...(payload || {}) }) },
      true
    ),

  createPackage: (payload: Partial<Package> & { courseIds?: string[] }) =>
    requestJson<{ package: Package }>(
      '/api/admin/packages',
      { method: 'POST', body: JSON.stringify(payload) },
      true
    ),

  updatePackage: (id: string, payload: Partial<Package> & { courseIds?: string[] }) =>
    requestJson<{ package: Package }>(
      `/api/admin/packages/${id}`,
      { method: 'PATCH', body: JSON.stringify(payload) },
      true
    ),

  reorderPackages: (packageIds: string[]) =>
    requestJson<{ packages: Package[] }>(
      '/api/admin/packages/reorder',
      { method: 'PUT', body: JSON.stringify({ packageIds }) },
      true
    ),

  deletePackage: (id: string) =>
    requestJson<{ success: boolean }>(`/api/admin/packages/${id}`, { method: 'DELETE' }, true),

  createCourse: (payload: Partial<Course>) =>
    requestJson<{ course: Course }>(
      '/api/admin/courses',
      { method: 'POST', body: JSON.stringify(payload) },
      true
    ),

  updateCourse: (id: string, payload: Partial<Course>) =>
    requestJson<{ course: Course }>(
      `/api/admin/courses/${id}`,
      { method: 'PATCH', body: JSON.stringify(payload) },
      true
    ),

  deleteCourse: (id: string) =>
    requestJson<{ success: boolean }>(`/api/admin/courses/${id}`, { method: 'DELETE' }, true),

  updatePackageCourses: (packageId: string, courseIds: string[]) =>
    requestJson<{ success: boolean }>(
      '/api/admin/package-courses',
      { method: 'PUT', body: JSON.stringify({ packageId, courseIds }) },
      true
    ),

  updateMemberStatus: (uid: string, status: 'active' | 'suspended') =>
    requestJson<{ user: UserProfile }>(
      `/api/admin/members/${uid}`,
      { method: 'PATCH', body: JSON.stringify({ status }) },
      true
    ),

  createOffer: (payload: { title: string; description: string; highlight: string; validUntil: string }) =>
    requestJson<{ success: boolean }>(
      '/api/admin/offers',
      { method: 'POST', body: JSON.stringify(payload) },
      true
    ),

  deleteOffer: (id: string) =>
    requestJson<{ success: boolean }>(`/api/admin/offers/${id}`, { method: 'DELETE' }, true),

  broadcastNotification: (payload: { userId: string; title: string; message: string }) =>
    requestJson<{ success: boolean }>(
      '/api/admin/notifications/broadcast',
      { method: 'POST', body: JSON.stringify(payload) },
      true
    ),

  replySupportTicket: (id: string, payload: { status: 'open' | 'in_progress' | 'resolved'; adminReply: string }) =>
    requestJson<{ success: boolean }>(
      `/api/admin/support/${id}/reply`,
      { method: 'POST', body: JSON.stringify(payload) },
      true
    ),

  updateSettings: (payload: Partial<AdminSettings>) =>
    requestJson<{ settings: AdminSettings }>(
      '/api/admin/settings',
      { method: 'PUT', body: JSON.stringify(payload) },
      true
    ),

  updateAdminAllowlist: (action: 'add' | 'remove', email: string) =>
    requestJson<{ adminAllowlist: string[] }>(
      '/api/admin/security/admins',
      { method: 'PUT', body: JSON.stringify({ action, email }) },
      true
    ),
};
